Roll No. CS19B1027
Name: Vibhanshu Jain

The source code is in SrcAssgn2-CS19B1027.cpp, 
Please use this command to complile, 
```
g++ SrcAssgn2-CS19B1027.cpp -pthread
```

The input values should be added in the file named inp-params.txt. It contains the value of n, k, lamda1 and lamda2 following the same order.
The outputs/logs will be added to the file names output.txt

To run the code, use the command
```
./a.out
```

