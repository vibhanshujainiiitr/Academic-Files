Name: Vibhanshu Jain
Roll No: CS19B1027

Operation System 2

RMS
C++ File: Assgn2-RMS-CS19B1027.cpp
Input File: inp-params.txt
Output Log File: RMS-Log.txt
Output Stats File: RMS-Stats.txt
Compilation: g++ Assgn2-RMS-CS19B1027.cpp -o rms.o

EDF
C++ File: Assgn2-EDF-CS19B1027.cpp
Input File: inp-params.txt
Output Log File: EDF-Log.txt
Output Stats File: EDF-Stats.txt
Compilation: g++ Assgn2-EDF-CS19B1027.cpp -o edf.o


 
