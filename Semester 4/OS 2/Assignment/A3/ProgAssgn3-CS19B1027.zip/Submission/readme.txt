Name: Vibhanshu Jain
Roll No: CS19B1027

Running the code
g++ -pthread name.cpp 
