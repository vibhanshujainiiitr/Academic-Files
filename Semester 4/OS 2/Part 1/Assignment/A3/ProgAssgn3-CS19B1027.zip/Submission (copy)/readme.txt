Name: Vibhanshu Jain
Roll No: CS19B1027

Input file
Name: inp-params.txt
It must contain four paramters which, are n, the total number of threads;the parameter k, parameter lambda1 and lambda2.

Compiling the code

TAS 
g++ -pthread SrcAssgn3-tas-CS19B1027.cpp

CAS
g++ -pthread SrcAssgn3-cas-CS19B1027.cpp

Bounded CAS
g++ -pthread SrcAssgn3-cas-bounded-CS19B1027.cpp

Running the code
Each code will generate a file name a.out which will be the executable file of that particular method. This file can be runned directly. 

The output log files will be automatically generated after the execution of the file a.out 
TAS Log: TAS-Log.txt
CAS Log: CAS-Log.txt
Bounded CAS Log: Bounded-CAS-Log.txt


