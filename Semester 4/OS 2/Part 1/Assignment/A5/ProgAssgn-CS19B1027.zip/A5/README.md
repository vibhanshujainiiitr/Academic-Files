Name: Vibhanshu Jain
Roll No: CS19B1027

Input file is input.txt, 
Where the first parameter is k, the number of partition
The next value is the total number of vertices.

For example. 
15 100

S

The Sequential Algorithm

Compiling:
clang++-7 -pthread -std=c++17 -o sequential CS19B1027-Assgn5-sequential.cpp

Running:
./sequential

The Coarse Grain Algorithm

Compiling:
clang++-7 -pthread -std=c++17 -o coarse CS19B1027-Assgn5-coarse.cpp

Running:
./coarse


The Fine-grained Algorithm

Compiling:
clang++-7 -pthread -std=c++17 -o fine CS19B1027-Assgn5-fine-grained.cpp

Running:
./fine