/*
Vibhanshu Jain
CS19B1027
*/

#include <iostream>
#include <list>
#include <sys/time.h>
#include <sys/times.h>
#include <fstream>
#include <random>
#include <cstdio>
#include <string>
#include <unistd.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

/* File output */
ofstream log_file;

// The list which contains the details of partation
list<int> *Part;

// Pointer to the list which contains the final result
int* result;

bool* available;
// The Graph class which contains all the fucntions

// The mutex lock
mutex mtx;
class Graph
{
public:
  int V;
  list<int> *adj;
  // The adjacency list
  
  // Contructor
  Graph(int V)
  {
    this->V = V;
    adj = new list<int>[V];
  }

  // Destructor
  ~Graph()
  {
    delete [] adj;
  }

  // Add edge function to add an edge between two vertices v and w 
  void addEdge(int v, int w)
  {
    // Both the input value passed is same then we cannot create edge.
    if(v==w)
      return;

    adj[v].push_back(w);
    adj[w].push_back(v);
  }


  // Function to find color without partation
  void greedyColoring();

  // Function to find color where P is the partation number
  void Coloring(int P);

};


void Graph::greedyColoring()
{
  int result[V];

  result[0] = 0;

  for(int u=1; u<V;u++)
    result[u] = -1;

  bool available[V];

  for(int cr=0; cr<V; cr++)
    available[cr] = false;
  
  for(int u=1; u<V; u++)
  {
    list<int>::iterator i;
    for( i = adj[u].begin(); i != adj[u].end(); ++i)
        if(result[*i] != -1)
          available[result[*i]] = true;
    
    int cr;
    for(cr=0; cr <V; cr++)
      if(available[cr]== false)
        break;
    
    result[u] = cr;

    for(i=adj[u].begin(); i!= adj[u].end(); ++i)
      if(result[*i] != -1)
        available[result[*i]] = false;
  
  }

  for(int u=0; u<V;u++)
    cout<< "Vertex "<<u<<"----> Color "<<result[u] <<endl;
}

void Coloring(Graph *G,int P) 
{ 

  // Acquiring the lock
  mtx.lock();

  // iterator for the list in the partation
  list<int>::iterator curr;
  for(curr = Part[P].begin(); curr != Part[P].end(); ++ curr)
  { 
    
    int u = *curr;
    
    // u is the vertex value which is there in the list of current partation

    // iterator for the adjacency list of the current vertex
    list<int>::iterator i;

    for( i = G->adj[u].begin(); i != G->adj[u].end(); i++)
    {
      if(result[*i] != -1)
        {
          int temp = result[*i];          
          available[result[*i]] = true;
        }
    }      

    int cr;
    for(cr=0; cr <G->V; cr++)
    {
      if(available[cr]== false)
      {
        break;
      }  
    }

    // coloring the vertex with the color which none of the adjacent vertex has
    result[u] = cr;
    
    for(i=G->adj[u].begin(); i!= G->adj[u].end(); ++i)
    {
      if(result[*i] != -1)
      { 
        available[result[*i]] = false;
      }
    }
  }

  // Releasing the lock
  mtx.unlock();
}

int main() {

  ifstream input;
  input.open("input.txt");
  
  // n is the number of threads, V is the number of vertex
  int n,V;
  input>>n>>V;

  input.close();
  log_file.open("Log.txt");

  // Dynamically allocating space for result
  result = (int*)malloc(sizeof(int)*V); 

  // Initilising the first vertex 0 color
  result[0] = 0;

  // Initilising the other vertex as not colored
  for(int u=1; u<V;u++)
    result[u] = -1;
  
  // Dynamically allocating space for available
  available = (bool*)malloc(sizeof(bool)*V);
  
  // Initilising all verteces to be unavailable
  for(int cr=0; cr<V; cr++)
    available[cr] = false;

  // Creating a graph G of the V vertex size
  Graph G(V);
  for(int i=0; i<V; i++)
  {
    for(int j=0; j<V; j++)
    { 
      if(i==j)
        continue;

      int temp = rand()%V;
      if(temp == i)
        continue;  
      G.addEdge(i, temp);
    }
  }

  // Till now we are just storing the edges in graph, now we needed to partation them.
  
  Part = new list<int>[n];
  // Defining the partation as the list

  //Assinging the partation

  srand(time(NULL));

  for(int i=0; i < V; i++)
  {
    Part[rand()%n].push_back(i);
    // Randomly allocating the partation to all vertex
  }

  // Calculating the time
  clock_t time;
  time = clock();


  thread worker[n];
  int data[n];
  // coloring for each partation
  for(int i=0; i<n;i++)
  {
	  data[i] = i;
    worker[i] = thread(&Coloring,&G, data[i]);
  }

  for(int i=0;i<n;i++){
	  worker[i].join();
  }  

  time = clock() - time;

  log_file<<"Coarse-Grained Lock"<<endl;

  int* numColor = max_element(result+0, result+V);
  log_file<<"No. of color used "<<*numColor<<endl;

  log_file<<"The time taken by algorithm "<< time<<" Miliseconds"<<endl;

  log_file<<"Coloring"<<endl;
  for(int u=0; u<V;u++)
  log_file<< "Vertex "<<u+1<<"----> Color "<<result[u] <<endl;
  log_file.close();
}
