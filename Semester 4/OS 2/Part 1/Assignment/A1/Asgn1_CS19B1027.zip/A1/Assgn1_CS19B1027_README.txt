Assignment 1 
Operating System 2

Name: Vibhanshu Jain
Roll No.: CS19B1027



Method 1 

Compiling commands: 
gcc Asgn1_CS19B1027_mth1.c -lpthread -lm -o mth1

Input file : input.txt
The first number is the parameter 'n' and followed by a space followed 'p'
Caution: n > p 
Example: 
10 2
12 5 

Running the code 
mth1 < input.txt > output.txt 

Output file
The out file will contain the array before sorting, then a line break, followed by the sorted array. 
At the last, the running time of the sorting algorithm. 



Method 2 

Compiling commands: 
gcc Asgn1_CS19B1027_mth2.c -lpthread -lm -o mth2

Input file : input.txt
The first number is the parameter 'n' and followed by a space followed 'p'
Caution: n > p 
Example: 
10 2
12 5 

Running the code 
mth2 < input.txt > output.txt 

Output file
The out file will contain the array before sorting, then a line break, followed by the sorted array. 
At the last, the running time of the sorting algorithm.
