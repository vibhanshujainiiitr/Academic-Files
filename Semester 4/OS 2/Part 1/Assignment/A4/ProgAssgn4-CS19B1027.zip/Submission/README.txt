Theory & Programming Assignment 4: The Korean Restaurant Problem
Vibhanshu Jain
CS19B1027

The Input is to given from the 'input.txt' file.
Where first number is 'n', the number of customers, followed by parameter x, then lambda, parameter r and I .
The Output file is "Log.txt"

The code can be compiled using, 
g++ -pthread main.cpp -o a.out 

where, a.out is the Output file.

The compiled code can be run using command, './a.out'.

